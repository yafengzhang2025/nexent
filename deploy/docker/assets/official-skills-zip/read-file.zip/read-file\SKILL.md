---
name: read-file
description: |
  读取指定路径的文件内容。路径应为工作区相对路径（例如 'documents/file.txt'）。出于安全考虑，不允许使用绝对路径。支持自定义编码，默认为 utf-8。返回文件内容字符串及文件元数据。
tags:
  - file
  - explorer
---

# 读取文件工具

读取工作区内指定路径的文件内容。

## 可用工具

read_file

## read_file参数

| 参数 | 类型 | 必填 | 默认值 | 说明 |
|------|------|------|--------|------|
| file_path | string | 是 | - | 要读取的文件的相对路径 |
| encoding | string | 否 | utf-8 | 文件编码 |

## 使用方式

<code>
file_content = read_file(file_path="documents/report.txt")
print(file_content)
</code>

## 返回值

read_file返回包含以下信息的 JSON 字符串：
- `status`: "success"
- `file_path`: 文件的相对路径
- `content`: 文件内容字符串
- `content_length`: 内容长度
- `file_size_bytes`: 文件大小（字节）
- `encoding`: 使用的编码
- `lines_count`: 行数

## 错误处理

| 错误 | 原因 | 解决方案 |
|------|------|----------|
| File does not exist | 路径不正确 | 验证文件路径是否存在 |
| Permission denied | 访问限制 | 检查文件权限 |
| Encoding error | 编码错误 | 尝试其他编码格式 |

## 备注

- 最大文件大小：10MB
- 安全限制：仅允许工作区相对路径

## 示例参考

> **注意**：仅当默认 Usage 示例不能满足需求时，再加载参考示例文件。

<reference path="examples.md" />