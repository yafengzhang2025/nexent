# 终端工具使用示例

本文档提供 terminal 的实际应用案例，覆盖主要参数组合场景。

---

## 示例 1：在独立会话中执行多条关联命令

**场景**：运维工程师需要在 /var/log 目录下依次执行 ls、grep 和 tail 命令来排查日志问题。

<code>
result = terminal(command="cd /var/log && ls -lh *.log | tail -5", session_name="log_analysis")
print(result)

result = terminal(command="grep ERROR app.log | tail -20", session_name="log_analysis")
print(result)
</code>

---

## 示例 2：执行有超时限制的后台检查命令

**场景**：SRE 工程师需要在部署前检查远程服务器的磁盘使用情况，设置 60 秒超时防止网络延迟。

<code>
result = terminal(command="df -h && du -sh /data/*", timeout=60)
print(result)
</code>

---

## 示例 3：使用管道组合命令完成数据处理

**场景**：数据工程师需要从日志文件中筛选出所有 POST 请求记录，并统计每个接口的调用次数。

<code>
result = terminal(command="cat /var/log/nginx/access.log | grep 'POST' | awk '{print $7}' | sort | uniq -c | sort -rn | head -20")
print(result)
</code>

---

## 示例 4：执行需要较长时间的构建命令

**场景**：CI/CD 流水线需要在远程构建服务器上执行 mvn package 构建 Java 项目，设置 5 分钟超时。

<code>
result = terminal(command="cd /build/workspace && mvn clean package -DskipTests", timeout=300)
print(result)
</code>

---

## 示例 5：在独立会话中部署应用

**场景**：运维人员需要在远程服务器上依次执行拉取镜像、停止旧容器、启动新容器的部署步骤。

<code>
result = terminal(command="docker pull registry.company.com/api-service:v2.4.1", session_name="deploy_v241")
print(result)

result = terminal(command="docker stop api-service && docker rm api-service", session_name="deploy_v241")
print(result)

result = terminal(command="docker run -d --name api-service -p 8080:8080 --restart always registry.company.com/api-service:v2.4.1", session_name="deploy_v241")
print(result)
</code>

---

## 示例 6：错误处理 — 命令执行超时

**场景**：网络不通或目标服务无响应时，执行 curl 请求会因超时而失败，需要捕获错误信息。

<code>
result = terminal(command="curl -s https://internal-service.company.com/health", timeout=10)
print(result)
</code>
