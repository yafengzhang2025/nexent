---
name: list-directory
description: |
  以树形结构格式列出目录内容。路径应为工作区相对路径（例如 'documents' 或 '.' 表示当前工作区）。出于安全考虑，不允许使用绝对路径。返回带有元数据的文件和目录层级树形视图。
tags:
  - directory
  - explorer
---

# 列出目录工具

以树形结构格式列出工作区内目录的内容。

## 可用工具

list_directory

## list_directory参数

| 参数 | 类型 | 必填 | 默认值 | 说明 |
|------|------|------|--------|------|
| directory_path | string | 否 | "." | 要列出的目录的相对路径 |
| max_depth | integer | 否 | 3 | 最大遍历深度（最大：10） |
| show_hidden | boolean | 否 | False | 显示隐藏文件/目录 |
| show_size | boolean | 否 | True | 显示文件大小 |

## 使用方式

<code>
result = list_directory(directory_path="documents", max_depth=3, show_hidden=False, show_size=True)
print(result)
</code>

## 返回值

list_directory返回包含以下信息的 JSON 字符串：
- `status`: "success"
- `directory_path`: 相对路径
- `tree_display`: 格式化的树形视图字符串
- `tree_data`: 层级 JSON 结构
- `summary`: 统计信息，包括 total_files、total_directories、total_size_bytes

## 错误处理

| 错误 | 原因 | 解决方案 |
|------|------|----------|
| Directory does not exist | 路径不正确 | 验证目录是否存在 |
| Path is not a directory | 路径指向文件 | 使用目录路径 |
| Permission denied | 访问限制 | 检查目录权限 |

## 备注

- 默认 "." 列出工作区根目录
- 为性能考虑最大深度限制为 10

## 示例参考

> **注意**：仅当默认 Usage 示例不能满足需求时，再加载参考示例文件。

<reference path="examples.md" />