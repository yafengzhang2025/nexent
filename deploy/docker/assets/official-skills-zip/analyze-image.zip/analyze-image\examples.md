# 分析图片工具使用示例

本文档提供 analyze-image 的实际应用案例，覆盖主要参数组合场景。

---

## 示例 1：分析单张产品图片

**场景**：电商运营人员上传了一张商品主图，需要 AI 为其生成商品描述文案。

<code>
results = analyze_image(image_urls_list=["s3://product-images/spu-8821-main.jpg"], query="请为这张商品图片生成一段适合电商平台的产品描述，包含产品外观特征、适用场景和风格特点，字数控制在100字以内。")
for result in results:
    print(result)
</code>

---

## 示例 2：批量分析多张图片生成对比报告

**场景**：用户上传了同一产品的正面、侧面、背面三张图片，需要生成完整的商品展示说明。

<code>
results = analyze_image(image_urls_list=[
    "s3://product-images/spu-8821-front.jpg",
    "s3://product-images/spu-8821-side.jpg",
    "s3://product-images/spu-8821-back.jpg"
], query="这是一个产品的三视图，请按顺序描述每张图片的内容，并总结该产品整体外观设计的主要特点。")
for result in results:
    print(result)
</code>

---

## 示例 3：分析网页截图识别 UI 元素

**场景**：自动化测试工程师需要从截图中识别界面上的关键按钮和输入框位置，用于生成测试用例。

<code>
results = analyze_image(image_urls_list=["https://cdn.example.com/ui-login-page.png"], query="请描述这个登录页面的UI布局，列出所有可见的输入框、按钮和标签的文本内容。")
for result in results:
    print(result)
</code>

---

## 示例 4：从身份证图片提取结构化信息

**场景**：金融服务应用需要自动识别用户上传的身份证照片，提取姓名、证件号、有效期等字段。

<code>
results = analyze_image(image_urls_list=["s3://user-uploads/id-card-20240115.jpg"], query="请从这张证件图片中提取以下信息并以JSON格式返回：证件类型、姓名、性别、出生日期、证件号码、有效期：起始日期、有效期：结束日期。如果某字段无法识别请标注null。")
for result in results:
    print(result)
</code>

---

## 示例 5：混合 S3 和 HTTP URL 来源

**场景**：用户同时上传了本地存储在 S3 的产品图和在线图片，需要一起分析用于竞品调研报告。

<code>
results = analyze_image(image_urls_list=[
    "s3://my-products/camera-a.jpg",
    "https://competitor.com/camera-b.jpg"
], query="请对比分析这两款相机产品图的外观设计差异，包括机身造型、按键布局和整体风格。")
for result in results:
    print(result)
</code>

---

## 示例 6：错误处理 — 图片 URL 无效

**场景**：用户提供了一个已过期或无权访问的图片链接。

<code>
results = analyze_image(image_urls_list=["https://expired-link.com/deleted-image.jpg"], query="描述这张图片的内容")
for result in results:
    print(result)
</code>
