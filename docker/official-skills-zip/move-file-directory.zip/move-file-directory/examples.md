# 移动项目使用示例

本文档提供 move_item 的实际应用案例，覆盖主要参数组合场景。

---

## 示例 1：整理文档 — 移动文件到归档目录

**场景：行政助理需要将 2023 年已完成的合同文件从 documents 目录移动到 archive/2023 归档目录。

<code>
result = move_item(
    source_path="documents/contracts/2023/supplier-agreement.pdf",
    destination_path="archive/2023/supplier-agreement.pdf"
)
print(result)
</code>

---

## 示例 2：使用移动文件完成重命名

**场景：开发者需要将项目中的模块进行重命名，文件内容不变但路径改变。

<code>
result = move_item(
    source_path="src/services/UserAuth.java",
    destination_path="src/services/SecurityService.java"
)
print(result)
</code>

---

## 示例 3：移动整个目录（保持内部结构）

**场景：项目迭代过程中需要将整个前端组件库迁移到新的项目结构目录下。

<code>
result = move_item(
    source_path="packages/ui-components",
    destination_path="libs/shared-ui-components"
)
print(result)
</code>

---

## 示例 4：移动到自动创建的父目录

**场景：构建产物需要移动到原本不存在的 build/release 目录下，工具会自动创建所需的父目录。

<code>
result = move_item(
    source_path="dist/app.js",
    destination_path="build/release/v2.4.0/app.js"
)
print(result)
</code>

---

## 示例 5：错误处理 — 目标路径已存在

**场景：用户尝试将一个文件移动到已存在同名文件的目标位置，需要防止意外覆盖。

<code>
result = move_item(
    source_path="docs/guide-v2.md",
    destination_path="docs/guide.md"
)
print(result)
</code>

---

## 示例 6：错误处理 — 源文件不存在

**场景：用户执行的移动脚本引用了一个已被删除的源文件，导致操作失败。

<code>
result = move_item(
    source_path="temp/cleaned-up-file.txt",
    destination_path="archive/cleaned-up-file.txt"
)
print(result)
</code>
