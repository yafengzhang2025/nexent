---
name: move-file-directory
description: |
  将文件或目录从源路径移动到目标路径。两个路径都应为工作区相对路径（例如 'documents/file.txt' 到 'backup/file.txt'）。出于安全考虑，不允许使用绝对路径。支持文件和目录移动。若目标目录不存在，将自动创建。
tags:
  - file
  - directory
  - explorer
---

# 移动项目工具

将文件或目录从源路径移动到工作区内的目标路径。

## 可用工具

move_item

## move_item参数

| 参数 | 类型 | 必填 | 默认值 | 说明 |
|------|------|------|--------|------|
| source_path | string | 是 | - | 源文件或目录的相对路径 |
| destination_path | string | 是 | - | 目标的相对路径 |

## 使用方式

<code>
result = move_item(source_path="documents/file.txt", destination_path="backup/file.txt")
print(result)
</code>

## 返回值

move_item返回包含以下信息的 JSON 字符串：
- `status`: "success"
- `source_path`: 原始相对路径
- `destination_path`: 新的相对路径
- `item_name`: 移动项目的名称
- `is_directory`: 指示类型的布尔值
- `size_bytes`: 移动项目的大小
- `items_moved`: 移动的项目数量（目录）

## 错误处理

| 错误 | 原因 | 解决方案 |
|------|------|----------|
| Source does not exist | 源路径不正确 | 验证源是否存在 |
| Destination already exists | 目标路径已被占用 | 选择不同的目标路径 |

## 备注

- 自动创建目标父目录
- 不能覆盖已存在的文件或目录
- 支持文件和目录移动

## 示例参考

> **注意**：仅当默认 Usage 示例不能满足需求时，再加载参考示例文件。

<reference path="examples.md" />