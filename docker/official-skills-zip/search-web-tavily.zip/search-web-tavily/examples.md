# Tavily 网络搜索使用示例

本文档提供 tavily_search 的实际应用案例，覆盖主要参数组合场景。

---

## 示例 1：搜索最新的金融资讯

**场景**：投资研究员需要在开盘前了解当日的宏观金融动态，准备晨会参考材料。

<code>
search_result = tavily_search(query="A股今日开盘 央行货币政策 最新动态")
print(search_result)
</code>

---

## 示例 2：获取多条结果做系统性行业分析

**场景**：市场分析师需要收集 10 篇关于新能源车行业竞争格局的文章，用于季度市场报告。

<code>
search_result = tavily_search(
    query="electric vehicle industry competition landscape China 2024 analysis",
    max_results=10
)
print(search_result)
</code>

---

## 示例 3：排除图片获取纯文本结果

**场景**：内容编辑在整理参考材料时需要引用文字内容，图片内容会干扰排版和引用。

<code>
search_result = tavily_search(
    query="React 18 new features concurrent rendering tutorial",
    image_filter=False
)
print(search_result)
</code>

---

## 示例 4：搜索技术问题解决方案

**场景**：后端工程师在生产环境遇到 Docker 容器内存溢出问题，需要快速搜索解决方案。

<code>
search_result = tavily_search(query="docker container OOM killed exit code 137 fix solution")
print(search_result)
</code>

---

## 示例 5：组合参数 — 控制结果数 + 排除图片

**场景**：运营人员在准备竞品分析报告时需要快速收集 5 篇纯文本格式的行业分析摘要。

<code>
search_result = tavily_search(
    query="SaaS market growth trends 2024 analyst report summary",
    max_results=5,
    image_filter=False
)
print(search_result)
</code>

---

## 示例 6：错误处理 — 无结果的无效查询

**场景**：用户搜索了完全无关或过于冷门的主题，系统需要给出空结果提示。

<code>
search_result = tavily_search(query="xyzabc123randomnonexistent")
print(search_result)
</code>
