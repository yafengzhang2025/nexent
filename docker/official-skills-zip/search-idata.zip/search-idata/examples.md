# iData 搜索使用示例

本文档提供 idata_search 的实际应用案例，覆盖主要参数组合场景。

---

## 示例 1：在指定知识空间搜索技术规格文档

**场景**：硬件工程师需要从"硬件规格库"中查找某型号芯片的引脚定义和电气参数文档。

<code>
search_result = idata_search(
    question="芯片引脚定义和电气参数",
    knowledge_space_id="hardware-specs"
)
print(search_result)
</code>

---

## 示例 2：组合参数 — 指定数据集 + 扩展结果数量

**场景**：数据科学家需要从机器学习相关的多个数据集（ml-papers 和 research-archive）中查找模型训练优化的参考文献。

<code>
search_result = idata_search(
    question="transformer模型训练优化技巧",
    dataset_ids='["ml-papers", "research-archive"]',
    top_k=15
)
print(search_result)
</code>

---

## 示例 3：在特定知识空间的数据集中精确查找

**场景**：财务分析师需要从"法规文档库"中查找上市公司关联交易信息披露的具体要求。

<code>
search_result = idata_search(
    question="上市公司关联交易信息披露规则",
    knowledge_space_id="regulatory-docs",
    dataset_ids='["compliance-kb"]'
)
print(search_result)
</code>

---

## 示例 4：搜索问题解决方案文档

**场景**：技术支持工程师需要查找关于"Kubernetes Pod 一直处于 Pending 状态"的诊断和解决方法的内部知识库文档。

<code>
search_result = idata_search(
    question="Kubernetes Pod Pending 状态 排查方法",
    knowledge_space_id="devops-troubleshooting"
)
print(search_result)
</code>

---

## 示例 5：组合参数 — 知识空间 + 数据集 + 控制结果数

**场景：产品经理需要从"用户体验研究库"中查找关于移动端表单设计的研究报告，限制返回 5 条最相关的。

<code>
search_result = idata_search(
    question="移动端表单设计 用户体验研究",
    knowledge_space_id="ux-research",
    dataset_ids='["ux-studies-kb"]',
    top_k=5
)
print(search_result)
</code>

---

## 示例 6：错误处理 — 缺少 API 密钥配置

**场景**：开发者刚接入 iData SDK 但尚未配置 API 密钥，调用搜索接口时收到明确的错误提示。

<code>
search_result = idata_search(question="测试查询")
print(search_result)
</code>
