---
name: search-idata
description: |
  提供 iData 知识库搜索能力。当用户需要搜索领域知识、技术文档或 iData 知识库中索引的任何信息时使用此工具。
tags:
  - search
  - idata
  - platform
---

# iData 搜索工具

在 iData 知识库中执行搜索，返回带有详细评分的相关结果。

## 可用工具

idata_search

## idata_search参数

| 参数 | 类型 | 必填 | 默认值 | 说明 |
|------|------|------|--------|------|
| question | string | 是 | - | 搜索查询词 |
| dataset_ids | string | 否 | - | 知识库 ID 的 JSON 字符串数组 |
| top_k | integer | 否 | 10 | 最大返回结果数 |

## 使用方式

<code>
search_result = idata_search(question="技术规格")
print(search_result)
</code>

## 返回值

idata_search返回包含搜索结果的 JSON 数组：
- `title`: 文档标题
- `url`: 下载 URL
- `text`: 文档内容
- `score`: 相关性分数
- `score_details`: reRankScore, vsScore, esScore

## 错误处理

| 错误 | 原因 | 解决方案 |
|------|------|----------|
| "server_url is required" | 缺少服务器地址 | 提供有效的 iData API 地址 |
| "api_key is required" | 缺少 API 密钥 | 提供有效的 iData API 密钥 |
| "No results found!" | 查询无结果 | 尝试更宽泛的查询词 |

## 备注

- 默认禁用 SSL 验证（支持自签名证书）
- 返回详细的评分信息

## 示例参考

> **注意**：仅当默认 Usage 示例不能满足需求时，再加载参考示例文件。

<reference path="examples.md" />