---
name: search-datamate
description: |
  提供 DataMate 知识库搜索能力。当用户需要搜索领域知识、技术文档或 DataMate 知识库中索引的任何信息时使用此工具。
tags:
  - search
  - knowledgebase
  - datamate
---

# DataMate 搜索工具

使用 datamate_search 方法在知识库中执行搜索，返回带有下载 URL 的相关结果。

## 可选工具

datamate_search

## datamate_search参数

| 参数 | 类型 | 必填 | 默认值 | 说明 |
|------|------|------|--------|------|
| query | string | 是 | - | 搜索查询词 |
| index_names | list | 否 | - | 索引名称列表 |
| top_k | integer | 否 | 3 | 最大返回结果数 |
| threshold | float | 否 | 0.2 | 相似度阈值 |
| rerank | boolean | 否 | False | 启用重排 |
| verify_ssl | boolean | 否 | False | 验证 SSL 证书 |

## 使用方式

<code>
search_result = datamate_search(query="产品规格说明")
print(search_result)
</code>

## datamate_search返回值

返回包含搜索结果的 JSON 数组：
- `title`: 文档名称
- `url`: 下载 URL
- `text`: 文档内容
- `score`: 相关性分数
- `score_details`: DataMate 特定元数据

## 错误处理

| 错误 | 原因 | 解决方案 |
|------|------|----------|
| "server_url is required" | 缺少服务器地址 | 提供有效的 DataMate 服务器地址 |
| "No knowledge base selected" | index_names 为空 | 提供有效的索引名称 |

## 示例参考

> **注意**：仅当默认 Usage 示例不能满足需求时，再加载参考示例文件。

<reference path="examples.md" />