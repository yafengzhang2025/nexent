---
name: email-utils
description: |
  用于获取和发送邮件的邮件工具集合。可以通过 IMAP 服务器获取邮件，支持按时间范围和发件人筛选；也可以通过 SMTP 向收件人发送 HTML 格式邮件。
tags: 
  - email
  - SMTP
  - IMAP
---

# 邮件工具

通过 IMAP/SMTP 协议获取和发送邮件的工具。

## 可用方法

get_email - 从 IMAP 服务器获取邮件

send_email - 通过 SMTP 发送 HTML 格式邮件

## get_email方法参数

| 参数 | 类型 | 必填 | 默认值 | 说明 |
|------|------|------|--------|------|
| days | integer | 否 | 7 | 获取过去 N 天的邮件 |
| sender | string | 否 | - | 按发件人邮箱地址筛选 |
| max_emails | integer | 否 | 10 | 最大获取邮件数量 |

## send_email方法参数

| 参数 | 类型 | 必填 | 默认值 | 说明 |
|------|------|------|--------|------|
| to | string | 是 | - | 收件人邮箱地址，多个用逗号分隔 |
| subject | string | 是 | - | 邮件主题 |
| content | string | 是 | - | 邮件内容（HTML 格式） |
| cc | string | 否 | - | 抄送邮箱地址，多个用逗号分隔 |
| bcc | string | 否 | - | 密送邮箱地址，多个用逗号分隔 |

## 使用方式

<code>
emails = get_email(days=7, sender="boss@company.com", max_emails=10)
for email in emails:
    print(email)
</code>

<code>
result = send_email(to="recipient@example.com", subject="会议通知", content="<h1>项目会议</h1><p>请于明天下午3点参加项目会议。</p>")
print(result)
</code>

## 返回值

get_email 返回 JSON 数组，包含：
- `subject`: 邮件主题
- `date`: 邮件日期
- `from`: 发件人地址
- `body`: 邮件正文内容

send_email 返回 JSON，包含：
- `status`: "success" 或 "error"
- `message`: 状态消息
- `to`: 收件人地址
- `subject`: 邮件主题

## 错误处理

| 错误 | 原因 | 解决方案 |
|------|------|----------|
| IMAP Error | 连接/登录失败 | 验证 IMAP 凭据 |
| SMTP Error | 连接/发送失败 | 验证 SMTP 凭据 |

## 备注

- IMAP 不支持按主题筛选
- 发件人必须是有效的邮箱地址
- 邮件内容应为 HTML 格式

## 示例参考

> **注意**：仅当默认 Usage 示例不能满足需求时，再加载参考示例文件。

<reference path="examples.md" />