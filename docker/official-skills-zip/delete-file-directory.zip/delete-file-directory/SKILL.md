---
name: delete-file-directory
description: |
  删除工作区内指定路径的文件或目录。路径应为工作区相对路径（例如 'documents/file.txt' 或 'documents/folder'）。出于安全考虑，不允许使用绝对路径。此操作不可逆。
tags:
  - file
  - directory
  - explorer
---

# 文件与目录删除工具

删除工作区内指定路径的文件或目录。工具会自动判断目标是文件还是目录，并执行相应的删除操作。

## 可用工具

delete_file - 删除单个文件

delete_directory - 删除目录及其所有内容

## delete_file参数

| 参数 | 类型 | 必填 | 默认值 | 说明 |
|------|------|------|--------|------|
| file_path | string | 是 | - | 要删除的文件的相对路径 |

## delete_directory参数

| 参数 | 类型 | 必填 | 默认值 | 说明 |
|------|------|------|--------|------|
| directory_path | string | 是 | - | 要删除的目录的相对路径 |

## 使用方式

<code>
result = delete_file(file_path="documents/temp.txt")
print(result)
</code>

<code>
result = delete_directory(directory_path="documents/old_folder")
print(result)
</code>

## 返回值

delete_file返回：
- `status`: "success"
- `file_path`: 已删除文件的相对路径
- `file_name`: 已删除文件的名称
- `file_size_bytes`: 原文件大小
- `message`: 成功消息

delete_directory返回：
- `status`: "success"
- `directory_path`: 已删除目录的相对路径
- `directory_name`: 已删除目录的名称
- `items_deleted`: 删除的项目数量
- `size_deleted_bytes`: 删除的总大小

## 错误处理

| 错误 | 原因 | 解决方案 |
|------|------|----------|
| File/Directory does not exist | 路径不正确 | 验证文件或目录是否存在 |
| Path is not a file/directory | 类型不匹配 | 确认目标是文件还是目录 |
| Permission denied | 访问限制 | 检查文件或目录权限 |
| Cannot delete workspace root | 尝试删除工作区根目录 | 指定一个子目录 |

## 备注

- 此操作不可逆
- 删除 .env、config 等重要文件时会触发警告
- 目录删除会递归删除所有内容
- 大型目录（>100 项）会触发警告
- 无法删除工作区根目录

## 示例参考

> **注意**：仅当默认 Usage 示例不能满足需求时，再加载参考示例文件。

<reference path="examples.md" />