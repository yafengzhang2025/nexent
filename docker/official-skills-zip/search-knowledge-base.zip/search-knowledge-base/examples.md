# 知识库搜索使用示例

本文档提供 knowledge_base_search 的实际应用案例，覆盖主要参数组合场景。

---

## 示例 1：使用混合搜索模式检索文档

**场景：企业内部门户机器人在收到用户提问"如何申请弹性办公"时，需要检索相关的公司政策文档。

<code>
search_result = knowledge_base_search(
    query="弹性办公申请流程和审批条件",
    search_mode="hybrid"
)
print(search_result)
</code>

---

## 示例 2：使用纯语义搜索查找概念相关文档

**场景：开发者不记得具体的配置项名称，但知道想要实现的功能概念是"超时自动重试"，需要找到相关文档。

<code>
search_result = knowledge_base_search(
    query="超时后自动重发请求的机制",
    search_mode="semantic"
)
print(search_result)
</code>

---

## 示例 3：使用精确匹配搜索查找标准术语

**场景：财务人员需要查找包含特定术语"OAuth2.0 授权流程"的公司技术标准文档，保证查准率。

<code>
search_result = knowledge_base_search(
    query="OAuth2.0 授权流程",
    search_mode="accurate"
)
print(search_result)
</code>

---

## 示例 4：组合参数 — 指定索引 + 启用重排 + 控制结果数

**场景：售前工程师需要从"解决方案库"中快速获取最相关的 5 份私有化部署方案文档，并对结果进行智能重排。

<code>
search_result = knowledge_base_search(
    query="私有化部署 网络隔离 数据安全",
    index_names=["解决方案库"],
    rerank=True,
    top_k=5
)
print(search_result)
</code>

---

## 示例 5：组合参数 — 语义搜索 + 重排 + 多索引

**场景：技术架构师在做技术选型时，需要在"架构设计库"和"技术标准库"中搜索微服务相关的最佳实践文档，并对结果做重排。

<code>
search_result = knowledge_base_search(
    query="微服务间通信 限流熔断方案",
    index_names=["架构设计库", "技术标准库"],
    search_mode="semantic",
    rerank=True,
    top_k=10
)
print(search_result)
</code>

---

## 示例 6：错误处理 — 未选择知识库索引

**场景：开发者调用 knowledge_base_search 时既没有在初始化时设置 index_names，也没有在调用时传入，导致索引为空。

<code>
search_result = knowledge_base_search(query="接口文档")
print(search_result)
</code>
