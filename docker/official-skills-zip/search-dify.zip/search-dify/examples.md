# Dify 搜索使用示例

本文档提供 dify_search 的实际应用案例，覆盖主要参数组合场景。

---

## 示例 1：基础语义搜索

**场景**：技术支持人员收到用户反馈"支付失败"，需要从 Dify 知识库中搜索相关的故障排查文档。

<code>
search_result = dify_search(query="支付失败 常见原因和解决方法")
print(search_result)
</code>

---

## 示例 2：在指定数据集内使用关键词搜索

**场景**：运维人员需要从"故障排查库"数据集中精确查找包含"502"关键词的错误处理文档。

<code>
search_result = dify_search(
    query="502 Bad Gateway",
    search_method="keyword_search"
)
print(search_result)
</code>

---

## 示例 3：全文搜索查找散布在多个文档中的内容

**场景**：产品经理需要搜索所有包含"用户留存率"这一数据指标的产品文档。

<code>
search_result = dify_search(
    query="用户留存率",
    search_method="full_text_search"
)
print(search_result)
</code>

---

## 示例 4：混合搜索平衡语义和关键词

**场景**：售前工程师需要为客户准备一份关于"私有化部署能力"的技术方案参考材料，希望结果既相关又有精准关键词匹配。

<code>
search_result = dify_search(
    query="私有化部署 数据安全 隔离方案",
    search_method="hybrid_search"
)
print(search_result)
</code>

---

## 示例 5：组合参数 — 指定数据集 + 关键词搜索 + 控制结果数

**场景**：HR 专员需要从"公司制度库"中精确查找所有关于年终奖发放规则的通知文档。

<code>
search_result = dify_search(
    query="年终奖",
    search_method="keyword_search",
    top_k=5
)
print(search_result)
</code>

---

## 示例 6：错误处理 — 未提供数据集 ID

**场景**：调用 dify_search 时未通过初始化参数或调用参数指定 dataset_ids。

<code>
search_result = dify_search(query="API接口文档")
print(search_result)
</code>
