---
name: search-dify
description: |
  提供 Dify 知识库搜索能力。当用户需要搜索领域知识、技术文档或 Dify 知识库中索引的任何信息时使用此工具。支持关键词搜索、语义搜索、全文搜索和混合搜索。
tags:
  - search
  - dify
---

# Dify 搜索工具

在 Dify 知识库中执行搜索，返回带有下载 URL 的相关结果。

## 可用工具

dify_search

## dify_search参数

| 参数 | 类型 | 必填 | 默认值 | 说明 |
|------|------|------|--------|------|
| query | string | 是 | - | 搜索查询词 |
| dataset_ids | string | 否 | - | 数据集 ID 的 JSON 字符串数组 |
| top_k | integer | 否 | 3 | 每个数据集的最大结果数 |
| search_method | string | 否 | "semantic_search" | 搜索方法 |

## search_method 搜索方法可选值

| 值 | 说明 |
|------|------|
| keyword_search | 关键词精确匹配 |
| semantic_search | 向量相似度 |
| full_text_search | 全文搜索 |
| hybrid_search | 组合方法 |

## 使用方式

<code>
search_result = dify_search(query="API文档")
print(search_result)
</code>

## 返回值

search_method返回包含搜索结果的 JSON 数组：
- `title`: 文档名称
- `url`: 下载 URL
- `text`: 文档内容
- `score`: 相关性分数

## 错误处理

| 错误 | 原因 | 解决方案 |
|------|------|----------|
| "server_url is required" | 缺少服务器地址 | 提供有效的 Dify API 基础地址 |
| "api_key is required" | 缺少 API 密钥 | 提供有效的 Dify API 密钥 |
| "dataset_ids is required" | 缺少数据集 ID | 提供有效的 JSON 数组 |

## 示例参考

> **注意**：仅当默认 Usage 示例不能满足需求时，再加载参考示例文件。

<reference path="examples.md" />