#!/usr/bin/env python3
"""Inspect the structure of a Word document."""

import argparse
import json
import os
import sys


DEFAULT_OUTPUT_DIR = "/mnt/nexent"


def get_document_info(path: str, working_dir: str = None) -> dict:
    """Inspect a Word document and return a basic structure summary."""
    if working_dir is None:
        working_dir = DEFAULT_OUTPUT_DIR

    from docx import Document

    abs_path = os.path.abspath(os.path.join(working_dir, path))

    if not os.path.exists(abs_path):
        raise FileNotFoundError(f"Document not found: {abs_path}")

    doc = Document(abs_path)

    info = {
        "status": "success",
        "file_path": path,
        "absolute_path": abs_path,
        "paragraphs_count": len(doc.paragraphs),
        "tables_count": len(doc.tables),
        "sections_count": len(doc.sections),
        "headings": []
    }

    for paragraph in doc.paragraphs:
        style_name = getattr(paragraph.style, "name", "")
        if style_name.startswith("Heading"):
            info["headings"].append({
                "text": paragraph.text,
                "style": style_name
            })

    return info


def main():
    parser = argparse.ArgumentParser(description="Inspect the structure of a Word document")
    parser.add_argument("--path", "-p", required=True, help="Document path")
    parser.add_argument("--working-dir", "-w", default=None,
                        help=f"Working directory (defaults to {DEFAULT_OUTPUT_DIR})")

    args = parser.parse_args()

    try:
        result = get_document_info(args.path, args.working_dir)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        sys.exit(0)
    except Exception as e:
        error_result = {"status": "error", "message": str(e)}
        print(json.dumps(error_result, ensure_ascii=False, indent=2))
        sys.exit(1)


if __name__ == "__main__":
    main()
