#!/usr/bin/env python3
"""Replace matching text in a Word document."""

import argparse
import json
import os
import sys


DEFAULT_OUTPUT_DIR = "/mnt/nexent"


def replace_text(path: str, old_text: str, new_text: str, working_dir: str = None) -> dict:
    """Replace matching text in an existing Word document."""
    if working_dir is None:
        working_dir = DEFAULT_OUTPUT_DIR

    from docx import Document

    abs_path = os.path.abspath(os.path.join(working_dir, path))

    if not os.path.exists(abs_path):
        raise FileNotFoundError(f"Document not found: {abs_path}")

    doc = Document(abs_path)
    replaced_count = 0

    for paragraph in doc.paragraphs:
        if old_text in paragraph.text:
            paragraph.text = paragraph.text.replace(old_text, new_text)
            replaced_count += 1

    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                if old_text in cell.text:
                    cell.text = cell.text.replace(old_text, new_text)
                    replaced_count += 1

    doc.save(abs_path)

    return {
        "status": "success",
        "file_path": path,
        "absolute_path": abs_path,
        "replaced_count": replaced_count
    }


def main():
    parser = argparse.ArgumentParser(description="Replace matching text in a Word document")
    parser.add_argument("--path", "-p", required=True, help="Document path")
    parser.add_argument("--old-text", required=True, help="Text to replace")
    parser.add_argument("--new-text", required=True, help="Replacement text")
    parser.add_argument("--working-dir", "-w", default=None,
                        help=f"Working directory (defaults to {DEFAULT_OUTPUT_DIR})")

    args = parser.parse_args()

    try:
        result = replace_text(args.path, args.old_text, args.new_text, args.working_dir)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        sys.exit(0)
    except Exception as e:
        error_result = {"status": "error", "message": str(e)}
        print(json.dumps(error_result, ensure_ascii=False, indent=2))
        sys.exit(1)


if __name__ == "__main__":
    main()
