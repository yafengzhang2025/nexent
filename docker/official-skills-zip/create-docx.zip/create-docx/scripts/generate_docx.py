#!/usr/bin/env python3
"""Generate a complete Word document from a structured specification in a single execution."""

import argparse
import json
import os
import sys
from pathlib import Path


DEFAULT_OUTPUT_DIR = "/mnt/nexent"


def generate_docx(spec: dict, output_path: str = None, working_dir: str = None) -> dict:
    """Generate a complete Word document from a structured specification.

    Args:
        spec: Document specification dict with keys:
            - title (str): Document title
            - sections (list): List of section dicts, each containing:
                - heading (str): Section heading text
                - heading_level (int): Heading level (1-9, default 2)
                - paragraphs (list): List of paragraph dicts:
                    - text (str): Paragraph text
                    - style (str, optional): Paragraph style
                    - bold (bool, optional): Bold text
                    - italic (bool, optional): Italic text
                - tables (list): List of table dicts:
                    - data (list): 2D array of cell values
                    - has_header (bool): Whether first row is header
        output_path: Output file name (default: from spec or 'output.docx')
        working_dir: Working directory (defaults to /mnt/nexent)
    """
    from docx import Document
    from docx.shared import Inches

    if working_dir is None:
        working_dir = DEFAULT_OUTPUT_DIR

    # Determine output path
    if output_path is None:
        output_path = spec.get("file_name", "output.docx")

    if not output_path.lower().endswith(".docx"):
        output_path += ".docx"

    abs_path = os.path.abspath(os.path.join(working_dir, output_path))
    Path(abs_path).parent.mkdir(parents=True, exist_ok=True)

    # Create document with default margins
    doc = Document()
    for section in doc.sections:
        section.top_margin = Inches(1)
        section.bottom_margin = Inches(1)
        section.left_margin = Inches(1)
        section.right_margin = Inches(1)

    # Add title (level 1 heading)
    if "title" in spec:
        doc.add_heading(spec["title"], level=1)

    # Process sections
    sections = spec.get("sections", [])
    for section in sections:
        # Add section heading
        heading = section.get("heading", "")
        heading_level = section.get("heading_level", 2)
        heading_level = max(1, min(9, heading_level))
        if heading:
            doc.add_heading(heading, level=heading_level)

        # Add paragraphs
        for para_spec in section.get("paragraphs", []):
            text = para_spec.get("text", "")
            if not text:
                continue

            style = para_spec.get("style")
            bold = para_spec.get("bold", False)
            italic = para_spec.get("italic", False)

            if style:
                paragraph = doc.add_paragraph(text, style=style)
            else:
                paragraph = doc.add_paragraph(text)

            if bold or italic:
                for run in paragraph.runs:
                    run.bold = bold
                    run.italic = italic

        # Add tables
        for table_spec in section.get("tables", []):
            table_data = table_spec.get("data", [])
            has_header = table_spec.get("has_header", True)

            if not table_data or not isinstance(table_data, list):
                continue

            rows = len(table_data)
            cols = len(table_data[0]) if table_data[0] else 0

            if rows < 1 or cols < 1:
                continue

            table = doc.add_table(rows=rows, cols=cols)
            table.style = "Table Grid"

            for i, row_data in enumerate(table_data):
                row = table.rows[i]
                for j, cell_data in enumerate(row_data):
                    if j < cols:
                        row.cells[j].text = str(cell_data)

            # Bold header row
            if has_header and rows > 0:
                header_row = table.rows[0]
                for cell in header_row.cells:
                    for para in cell.paragraphs:
                        for run in para.runs:
                            run.font.bold = True

    doc.save(abs_path)

    # Get file size
    stat = os.stat(abs_path)
    file_size = stat.st_size

    return {
        "status": "success",
        "file_path": output_path,
        "absolute_path": abs_path,
        "file_name": os.path.basename(abs_path),
        "file_size_bytes": file_size,
        "file_size_formatted": _format_size(file_size),
        "mime_type": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "message": "Document created successfully."
    }


def _format_size(size_bytes: int) -> str:
    """Format file size in human-readable format."""
    for unit in ["B", "KB", "MB", "GB"]:
        if size_bytes < 1024:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024
    return f"{size_bytes:.1f} TB"


def main():
    parser = argparse.ArgumentParser(
        description="Generate a complete Word document from a JSON specification"
    )
    parser.add_argument("--spec", "-s", required=True,
                        help="Document specification as JSON string")
    parser.add_argument("--output", "-o", default=None,
                        help="Output file name (default: from spec or 'output.docx')")
    parser.add_argument("--spec-file", "-f", default=None,
                        help="Path to JSON file containing the specification")
    parser.add_argument("--working-dir", "-w", default=None,
                        help=f"Working directory (defaults to {DEFAULT_OUTPUT_DIR})")

    args = parser.parse_args()

    try:
        # Load specification
        if args.spec_file:
            with open(args.spec_file, "r", encoding="utf-8") as f:
                spec = json.load(f)
        else:
            spec = json.loads(args.spec)

        result = generate_docx(spec, args.output, args.working_dir)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        sys.exit(0)
    except json.JSONDecodeError as e:
        error_result = {"status": "error", "message": f"Invalid JSON specification: {e}"}
        print(json.dumps(error_result, ensure_ascii=False, indent=2))
        sys.exit(1)
    except Exception as e:
        error_result = {"status": "error", "message": str(e)}
        print(json.dumps(error_result, ensure_ascii=False, indent=2))
        sys.exit(1)


if __name__ == "__main__":
    main()
