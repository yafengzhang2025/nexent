#!/usr/bin/env python3
"""Get the path and metadata of a Word document."""

import argparse
import json
import os
import sys
from pathlib import Path


# Default directory for generated files (same as other file creation tools)
DEFAULT_OUTPUT_DIR = "/mnt/nexent"


def get_document_path(path: str, working_dir: str = None) -> dict:
    """Get the path and metadata of a Word document for frontend preview.

    Args:
        path: Document file name
        working_dir: Working directory (defaults to /mnt/nexent)
    """
    if working_dir is None:
        working_dir = DEFAULT_OUTPUT_DIR

    abs_path = os.path.abspath(os.path.join(working_dir, path))

    if not os.path.exists(abs_path):
        raise FileNotFoundError(f"Document not found: {abs_path}")

    if not abs_path.lower().endswith(".docx"):
        raise ValueError(f"Not a Word document: {abs_path}")

    stat = os.stat(abs_path)
    file_size = stat.st_size

    # Get relative path for display
    try:
        rel_path = os.path.relpath(abs_path, os.getcwd())
    except ValueError:
        rel_path = abs_path

    return {
        "status": "success",
        "file_path": rel_path,
        "absolute_path": abs_path,
        "file_name": os.path.basename(abs_path),
        "file_size_bytes": file_size,
        "file_size_formatted": _format_size(file_size),
        "mime_type": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "message": f"Document ready for upload: {rel_path}"
    }


def _format_size(size_bytes: int) -> str:
    """Format file size in human-readable format."""
    for unit in ["B", "KB", "MB", "GB"]:
        if size_bytes < 1024:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024
    return f"{size_bytes:.1f} TB"


def main():
    parser = argparse.ArgumentParser(description="Get Word document path for preview")
    parser.add_argument("--path", "-p", required=True, help="Document path")
    parser.add_argument("--working-dir", "-w", default=None,
                        help=f"Working directory (defaults to {DEFAULT_OUTPUT_DIR})")

    args = parser.parse_args()

    try:
        result = get_document_path(args.path, args.working_dir)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        sys.exit(0)
    except Exception as e:
        error_result = {"status": "error", "message": str(e)}
        print(json.dumps(error_result, ensure_ascii=False, indent=2))
        sys.exit(1)


if __name__ == "__main__":
    main()
