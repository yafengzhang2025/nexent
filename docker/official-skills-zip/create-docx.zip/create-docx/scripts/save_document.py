#!/usr/bin/env python3
"""Save (and optionally verify) a Word document."""

import argparse
import json
import os
import sys


# Default directory for generated files (same as other file creation tools)
DEFAULT_OUTPUT_DIR = "/mnt/nexent"


def save_document(path: str, working_dir: str = None) -> dict:
    """Save a Word document and verify it exists."""
    if working_dir is None:
        working_dir = DEFAULT_OUTPUT_DIR

    abs_path = os.path.abspath(os.path.join(working_dir, path))

    if not os.path.exists(abs_path):
        raise FileNotFoundError(f"Document not found: {abs_path}")

    # Get file info
    stat = os.stat(abs_path)
    file_size = stat.st_size

    return {
        "status": "success",
        "file_path": path,
        "absolute_path": abs_path,
        "file_size_bytes": file_size,
        "message": f"Document saved successfully ({file_size} bytes)"
    }


def main():
    parser = argparse.ArgumentParser(description="Save and verify a Word document")
    parser.add_argument("--path", "-p", required=True, help="Document path")
    parser.add_argument("--working-dir", "-w", default=None,
                        help=f"Working directory (defaults to {DEFAULT_OUTPUT_DIR})")

    args = parser.parse_args()

    try:
        result = save_document(args.path, args.working_dir)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        sys.exit(0)
    except Exception as e:
        error_result = {"status": "error", "message": str(e)}
        print(json.dumps(error_result, ensure_ascii=False, indent=2))
        sys.exit(1)


if __name__ == "__main__":
    main()
