---
name: search-web-exa
description: |
  使用 Exa API 提供互联网搜索能力。当用户需要搜索实时信息、新闻、常识或非专有数据时使用此工具。
tags:
  - search
  - exa
  - web
---

# Exa 网络搜索工具

使用 Exa API 执行互联网搜索，返回带有文本内容的相关结果。

## 可用工具

exa_search

## exa_search参数

| 参数 | 类型 | 必填 | 默认值 | 说明 |
|------|------|------|--------|------|
| query | string | 是 | - | 搜索查询词 |
| max_results | integer | 否 | 3 | 最大返回结果数 |
| image_filter | boolean | 否 | True | 启用图片过滤 |

## 使用方式

<code>
search_result = exa_search(query="Python最佳实践")
print(search_result)
</code>

## 返回值

exa_search返回包含搜索结果的 JSON 数组：
- `title`: 结果标题
- `url`: 来源 URL
- `text`: 内容摘要
- `published_date`: 发布日期
- `cite_index`: 引用索引

## 错误处理

| 错误 | 原因 | 解决方案 |
|------|------|----------|
| "No results found!" | 查询无结果 | 尝试更宽泛的查询词 |
| API error | API 密钥无效 | 验证 Exa API 密钥 |

## 备注

- 图片过滤使用外部数据处理服务
- 每个结果的文本内容限制为 2000 字符
- 使用 livecrawl 模式获取最新内容

## 示例参考

> **注意**：仅当默认 Usage 示例不能满足需求时，再加载参考示例文件。

<reference path="examples.md" />